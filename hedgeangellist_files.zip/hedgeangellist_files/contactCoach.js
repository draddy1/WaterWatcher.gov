var dialog = {

    createDialog:function(coach){

        var _self = this;
        _self.coach = coach;
        $('body').append('<div class="mailCoachForm"></div>');
        _self.centerForm();

        $('.mailCoachForm').append(
            '<p class="coachText">Your request will be passed directly to the coach, and treated with the utmost confidence.</p>' +
            '<label>*Name</label>' + '<input class="name" name="name" type="text">' +
            '<label>*Company</label>' + '<input class="company" name="company" type="text">' +
            '<label>*Email Address</label>' + '<input class="email" name="email" type="text">' +
            '<label>Telephone</label>' + '<input class="telephone" name="telephone" type="text">' +
            '<label>Comment</label>' + '<textarea rows="4" cols="5" class="comment" name="comment"></textarea>' +
            '<button class="mailCoachSubmit">Send</button>' +
            '<button class="mailCoachCancel">Cancel</button>'
            );

        $('.mailCoachSubmit').click(_self, _self.clickFunc);
        $('.mailCoachCancel').click('click', _self.cancelFunc.bind(_self));
    },
    clickFunc:function(_self){

        if(_self.data.validate()){
            _self.data.sendAjax();
        } else {
            alert('Form not valid');
        }
    },
    cancelFunc:function(){
        this.resetDialog();
    },
    validate:function(){
        if( $('.name').val() == ""){ return false}
        if( $('.company').val() == ""){ return false}
        if( $('.email').val() == ""){ return false}

        function validateEmail(email) {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        if( validateEmail($('.email').val()) ){ return true} else { return false}

        return true;
    },
    centerForm:function(){
        var windowHeight=$(window).height();

        var windowWidth=parseInt($(window).width())

        var panelHeight=500
        var windowHeight=parseInt($(window).height())

        $('.mailCoachForm').css('top',  $(document).scrollTop() + (windowHeight/2) - (panelHeight/2) )
    },
    sendAjax:function(){

        var _self = this;

        var data = {
            coach: _self.coach,
            name: $('.name').val(),
            company: $('.company').val(),
            email: $('.email').val(),
            telephone: $('.telephone').val(),
            comment: $('.comment').val()
        }

        $.ajax({
            type: "POST",
            url: "/wp-content/themes/essentia/sendCoachMail.php",
            data: data,
            context:_self
        }).done(function(data, index) {
            this.removeDialog();
        });

        //sendCoachMail.php
    },
    removeDialog:function(){
        location.reload();
    },
    resetDialog:function(){
        $('.mailCoachForm').remove();
    }
}