$.noConflict();

jQuery(window).load(function() {

				/*Google Map---------------*/
				if(document.getElementById("get-in-touch") != null)
				{

					var markers = [{
					"title" : 'Alibaug',
					"lat" :  essantia1.lat,
					"lng" : essantia1.lon
					//	"description" : ''

					}];

					var mapOptions = {
						center : new google.maps.LatLng(markers[0].lat, markers[0].lng),
						zoom : 14,
						scrollwheel: false,
						mapTypeId : google.maps.MapTypeId.ROADMAP

					};
					var infoWindow = new google.maps.InfoWindow();

					var map = new google.maps.Map(document.getElementById("get-in-touch"), mapOptions);
					//alert("aa");
					var i = 0;

					var interval = setInterval(function() {
						var data = markers[i]
						var myLatlng = new google.maps.LatLng(data.lat, data.lng);
						var marker = new google.maps.Marker({
							position : myLatlng,
							map : map,
							title : data.title,
							animation : google.maps.Animation.DROP,
							icon : essantia1.gicon
						});
						(function(marker, data) {
							google.maps.event.addListener(marker, "click", function(e) {
								infoWindow.setContent(data.description);
								infoWindow.open(map, marker);
							});
						})(marker, data);
						i++;
						if (i == markers.length) {
							clearInterval(interval);
						}
					}, 200);

				}



				/*Google MAp-----------Close*/



				/* JS_HTML5_P_Team.......................OPEN*/
				var navarr = new Array();
				var desInd = 0;
				var isSmoothScoling = false;
				jQuery('.nav').each(function(){
					if(jQuery(this).css("display") != "none")
					{
						//alert("dffd");

						jQuery(this).find('li a').each(function(){
							if(this.hash!= "")
							{
								var str = jQuery(this).attr("href");
								//alert(jQuery(str).offset().top);
								if(jQuery(str).length > 0)
								{
									var navobj = {
										obj:jQuery(this),
										id:jQuery(str),
										top:(jQuery(str).offset().top - parseInt(83))
									}
									//console.log(jQuery(this.hash).offset().top - parseInt(83))
									navarr.push(navobj);
								}


							}
				});

					}
				});

				//console.log(navarr.length);
				var isSmoothScoling = false;

				jQuery(window).scroll(function(){
					if(!isSmoothScoling)
					{
						onManualScrolling()
					}

				});
				function onManualScrolling()
				{
					var scrol = jQuery(window).scrollTop();
					for(var i =0;i < navarr.length; )
					{
						if(i+1 >navarr.length-1)
						{
								//desInd = i;
								jQuery(".nav li").removeClass('active');
								navarr[navarr.length-1].obj.parent().addClass('active');
								break;
						}
						else
						{
							if(scrol > navarr[i].top && scrol < navarr[i+1].top)
							{
								desInd = i;
								jQuery(".nav li").removeClass('active');
								navarr[i].obj.parent().addClass('active');
								break;
							}
							else
							{
								i++;
							}
						}

					}
				}
				/* JS_HTML5_P_Team.......................CLOSE*/


				jQuery('a[href^="#"]').bind('click.smoothscroll', function(e) {
					if(this.hash != '')
					{
						e.preventDefault();
						//alert("dffdf");
						var target = this.hash;
						isSmoothScoling = true;
						jQuerytarget = jQuery(target);
						if(jQuerytarget.length > 0)
						{
							//alert(parseInt(jQuerytarget.offset().top));
							goto = parseInt(jQuerytarget.offset().top) - parseInt(83)
							jQuery('html, body').stop().animate({
								'scrollTop' : goto
							}, 2000, 'swing', function() {
								setTimeout(setSmoothScolingFalse,20);
								// window.location.hash = target;
							});
						}

					}

				});

				/* JS_HTML5_P_Team.......................OPEN*/
				function setSmoothScolingFalse()
				{
					isSmoothScoling = false;
					setScrollPosition();
				}


				function setScrollPosition()
				{
					var scrol = jQuery(window).scrollTop();
					for(var i =0;i < navarr.length;i++ )
					{
						//console.log(scrol);
						//console.log(parseInt(navarr[i].top));
						if(scrol == parseInt(navarr[i].top))
						{
								//desInd = i;
								jQuery(".nav li").removeClass('active');
								navarr[i].obj.parent().addClass('active');
								break;
						}
					}

				}
		/* JS_HTML5_P_Team.......................close*/


			});



			jQuery(document).ready(function() {
					function setupLabel() {
				if (jQuery('.wpcf7-list-item label input').length) {
					jQuery('.wpcf7-list-item label').each(function() {
						jQuery(this).removeClass('c_on');
					});
					jQuery('.wpcf7-list-item label input:checked').each(function() {
						jQuery(this).parent('label').addClass('c_on');
					});
				};

				if (jQuery('.label_radio input').length) {
					jQuery('.label_radio').each(function() {
						jQuery(this).removeClass('r_on');
					});
					jQuery('.label_radio input:checked').each(function() {
						jQuery(this).parent('label').addClass('r_on');
					});
				};
			};
				jQuery('.wpcf7-list-item label, .label_radio').click(function() {
					setupLabel();
				});
				setupLabel();
				var window_height = jQuery(window).height()
				jQuery('.home').css('min-height', window_height)
				jQuery('#btnToggle').click(function() {
					jQuery('#dvText').slideToggle(1000);
					return false;
				});
				jQuery('#dvText').css('display', 'none');

				jQuery(".nav li").click(function() {

					jQuery(".nav li").removeClass('active')
					jQuery(this).addClass('active');

				});
				jQuery(".pagination li").click(function() {

					jQuery(".pagination li").removeClass('active')
					jQuery(this).addClass('active');

				});


			var sliderObj = '';
		sliderObj = jQuery('.bxslider').bxSlider({
					mode : 'horizontal'
				});

				var ccc = 1;
			jQuery('#insights123').click(function() {
				if (ccc) {
					jQuery('.InsightsDropDown').css('display', 'block');
					ccc = 0;
				} else {
					jQuery('.InsightsDropDown').css('display', 'none');
					ccc = 1;
				}
			})
			jQuery('.InsightsDropDown li').click(function() {
				var gotoSlide = jQuery(this).index();

				sliderObj.goToSlide(gotoSlide);

				jQuery('#insights123').text(jQuery(this).text());
				jQuery('.InsightsDropDown').css('display', 'none');
				ccc = 1;
			})

			jQuery('.slides li').click(function() {
				var ind = jQuery(this).index();
				sliderObj.goToSlide(ind);
			})
			var a=1;
			var sliderObjShow = null;
			var b=1;
			var sliderObjShow2 = null;
            var c=1;
			var sliderObjShow3 = null;

				jQuery("div.show-panel").click(function() {
					var ind = jQuery(this).index();
					sliderInit(ind);
				});

				window.addEventListener("resize", function() {

					if(sliderObjShow!=null)
					{
						jQuery(".lightbox, .lightbox-panel").fadeOut(20);
						sliderObjShow.destroySlider();

		            	a = 1;
					}


					if(sliderObjShow2!=null)
					{
						jQuery(".lightbox, .lightbox-panel-2").fadeOut(20);
						sliderObjShow2.destroySlider();
	            		b = 1;
					}

                    if(sliderObjShow3!=null)
					{

						jQuery(".lightbox, .lightbox-panel-3").fadeOut(20);
						sliderObjShow3.destroySlider();
                        dialog.removeDialog();
	            		c = 1;
					}

}, false);
			var sliderHtml;
			function sliderInit(ind)
			{
				var windowHeight=jQuery(window).height();
			    var contentHeight=jQuery('.lightbox-panel').height();
			    if(jQuery(windowHeight>contentHeight)){

				   jQuery('.lightbox-panel').css('position','fixed')
				   var panelWidth=parseInt(jQuery('.lightbox-panel').width())
			       var windowWidth=parseInt(jQuery(window).width())

				   var panelHeight=parseInt(jQuery('.lightbox-panel').height())
			     var windowHeight=parseInt(jQuery(window).height())

			       jQuery('.lightbox-panel').css('left',(windowWidth-panelWidth)/2)
			       if(a==1)
			       {
			       	 jQuery('.lightbox-panel').css('top',(windowHeight-panelHeight)/2 + (-(windowHeight-panelHeight)/2)+50)
			       	 //jQuery('.lightbox-panel').css('top',(windowHeight-panelHeight)/2)
			       }
			       else
			       {
			       	jQuery('.lightbox-panel').css('top',(windowHeight-panelHeight)/2)
			       }
				}
				//new js end
								if(a==1){

								//jQuery.getScript("/wp-content/themes/essentia/assets/js/jquery.bxslider.min.js?ver=3.6.1")
								sliderObjShow = jQuery('.bxslider-1').bxSlider({
														mode : 'horizontal',
								  						adaptiveHeight: true,
								  						startSlide : ind

														});
													a++;


							}
								jQuery(".lightbox").fadeIn(500,function(){

										sliderObjShow.goToSlide(ind);



								});
								jQuery(".lightbox-panel").fadeIn(500,function(){});



			}




				jQuery("a.light-closed").click(function(){
jQuery(".lightbox, .lightbox-panel").fadeOut(300);
});

				jQuery('.lightbox').click(function() {
					jQuery(".lightbox, .lightbox-panel").fadeOut(300);
					jQuery(this).fadeOut(300);
				});

jQuery("#carousel .slides li").hover(function(){
		var hover = jQuery(this).find("i").attr("data-url");

		//alert(str);
		jQuery(this).find("i").css("background-image","url("+hover+")");

		},function(){
			var normal = jQuery(this).find("i").attr("data-source");
			//alert(normal);
			if(jQuery(this).attr("class") != "active")
				jQuery(this).find("i").css("background-image","url("+normal+")");
		});

/////////////////////////////////////////////
//*****   second light box open here ****///
////////////////////////////////////////////

jQuery("div.show-panel-two").click(function() {

	var ind = jQuery(this).index();
	sliderInit2(ind);


});


		function sliderInit2(ind)
		{



				var windowHeight=jQuery(window).height();

				var contentHeight=jQuery('.lightbox-panel-2').height();

				if(jQuery(windowHeight>contentHeight)){


				jQuery('.lightbox-panel-2').css('position','fixed')

				var panelWidth=parseInt(jQuery('.lightbox-panel-2').width())

				var windowWidth=parseInt(jQuery(window).width())


				var panelHeight=parseInt(jQuery('.lightbox-panel-2').height())

				var windowHeight=parseInt(jQuery(window).height())


				jQuery('.lightbox-panel-2').css('left',(windowWidth-panelWidth)/2)

				if(b==1)

				{

				jQuery('.lightbox-panel-2').css('top',(windowHeight-panelHeight)/2 + (-(windowHeight-panelHeight)/2)+50)

				}

				else

				{

				jQuery('.lightbox-panel-2').css('top',(windowHeight-panelHeight)/2)

				}




				}


				if(b==1){

				sliderObjShow2 = jQuery('.bxslider-2').bxSlider({

					mode : 'horizontal',
					adaptiveHeight: true,
					startSlide : ind

				});

					b++;

				}


				jQuery(".lightbox").fadeIn(300,function(){
					sliderObjShow2.goToSlide(ind);
				});

				jQuery(".lightbox-panel-2").fadeIn(300,function(){

				});

		}

jQuery("a.light-closed").click(function(){

jQuery(".lightbox, .lightbox-panel-2").fadeOut(300);

});


jQuery('.lightbox').click(function() {
jQuery(".lightbox, .lightbox-panel-2").fadeOut(300);

jQuery(this).fadeOut(300);

});

//second light box close here

//third light box open here
jQuery("div.show-panel-three").click(function() {

	var ind = jQuery(this).index();
	sliderInit3(ind);
});
		function sliderInit3(ind)
		{

				var windowHeight=jQuery(window).height();

				var contentHeight=jQuery('.lightbox-panel-3').height();


				if(jQuery(windowHeight>contentHeight)){

				jQuery('.lightbox-panel-3').css('position','fixed')

				var panelWidth=parseInt(jQuery('.lightbox-panel-3').width())

				var windowWidth=parseInt(jQuery(window).width())


				var panelHeight=parseInt(jQuery('.lightbox-panel-3').height())

				var windowHeight=parseInt(jQuery(window).height())


				jQuery('.lightbox-panel-3').css('left',(windowWidth-panelWidth)/2)

				if(c==1)

				{

				jQuery('.lightbox-panel-3').css('top',(windowHeight-panelHeight)/2 + (-(windowHeight-panelHeight)/2)+50)

				}

				else

				{

				jQuery('.lightbox-panel-3').css('top',(windowHeight-panelHeight)/2)

				}




				}


				if(c==1){

				    sliderObjShow3 = jQuery('.bxslider-3').bxSlider({

					mode : 'horizontal',
					adaptiveHeight: true,
					startSlide : ind
                    });

					c++;

				}

				jQuery(".lightbox").fadeIn(300,function(){
					sliderObjShow3.goToSlide(ind);
				});

				jQuery(".lightbox-panel-3").fadeIn(300,function(){

				});

		}

jQuery("a.light-closed").click(function(){

jQuery(".lightbox, .lightbox-panel-3").fadeOut(300);

});


jQuery('.lightbox').click(function() {
jQuery(".lightbox, .lightbox-panel-3").fadeOut(300);

jQuery(this).fadeOut(300);

});



//third light box close here

jQuery("#process .data-content").each(function(){
	if(jQuery(this).index()%2 != 0)
	{
		jQuery(this).addClass("none");
	}

});

if(jQuery(window).width()>=320 && jQuery(window).width()<=767 ){
		jQuery('.nav a').click(function() {
			 jQuery('#dvText').fadeOut(1000);
		});
		}
		var abc = document.getElementById("get-in-touch");
		// abc.ontouchmove = function(e)
		// {
			// e.preventDefault()
			// mapOptions.draggable = false;
		// }

});


